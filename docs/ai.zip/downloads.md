# Downloads - HL7 AU FHIR Namespace Registry v0.1.0

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

### Downloadable copy of entire specification

A downloadable version of the entire implementation guide is available so it can be hosted locally:

* [Downloadable Copy](full-ig.zip)

### Package file

The following package file includes an NPM package file used by many of the FHIR tools. It contains all the value sets, profiles, extensions, list of pages and urls in the IG, etc defined as part of this version of the Implementation Guides. This file should be the first choice whenever generating any implementation artefacts since it contains all of the rules about what makes the profiles valid. Implementers will still need to be familiar with the content of the specification and profiles that apply in order to make a conformant implementation:

* [Package](package.tgz)

See the overview on [validating FHIR profiles and resources](http://hl7.org/fhir/R4/validation.html) for more information about validating profiles and how to use these artefacts

