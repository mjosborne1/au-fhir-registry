# Home - HL7 AU FHIR Namespace Registry v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.au/fhir/nsreg/ImplementationGuide/hl7.fhir.au.nsreg | *Version*:0.1.0 |
| Draft as of 2026-05-06 | *Computable Name*:AUNSRegistry |

# au-fhir-registry

Repository of AU Domain Namespaces as FHIR NamimgSystems

* NamingSystem: [ABN](NamingSystem-ABN.md)
  * ?: Australian Business Number (ABN) is a unique 11 digit number that identifies a business or organisation in Australia. ABN lookup is available here https://abr.business.gov.au/.
* NamingSystem: [ACN](NamingSystem-ACN.md)
  * ?: This identifier identifies an Australian Company Number in an Australian context. An ACN is allocated by the Australian Securities and Investments Commission (ASIC) when a body becomes registered as a company under Corporations Law.
* NamingSystem: [AHPRANumber](NamingSystem-AHPRANumber.md)
  * ?: An Australian Health Practitioner Regulation Authority (AHPRA) registration number assigned to a practitioner for each profession in which they are registered. Practitioners registered in more than one profession have one registration number for each profession.
* NamingSystem: [ARBN](NamingSystem-ARBN.md)
  * ?: This identifier identifies a registrable Australian body. Companies must apply to Australian Securities and Investments Commission (ASIC) to be issued an ARBN if they wish to operate in Australia. Foreign companies also require an ARBN.
* NamingSystem: [AUNATAAccreditationNumber](NamingSystem-AUNATAAccreditationNumber.md)
  * ?: National Association of Testing Authorities (NATA) Accreditation Number is used to identify approved testing laboratories in the Australian context.
* NamingSystem: [AUNATASiteNumber](NamingSystem-AUNATASiteNumber.md)
  * ?: National Association of Testing Authorities (NATA) Accreditation Number is used to identify approved testing laboratory locations in the Australian context.
* NamingSystem: [AustalianDVAFileNumber](NamingSystem-DVANumber.md)
  * ?: Australian Department of Veterans’ Affairs (DVA) file number. An individual’s state-based Department of Veterans’ Affairs (DVA) File number as displayed on a Veteran Card.
* NamingSystem: [AustralianCRN](NamingSystem-CentrelinkCustomerReferenceNumber.md)
  * ?: Centrelink Customer Reference Number (also referred to as unique identifier number (UIN) in the Centrelink Confirmation eServices (CCeS)). An identifier assigned to an individual by Centrelink for the purposes of identifying people (and organisations) eligible for specific services, including some public health care services, such as oral health services. This number may appear on a Health Care Card, Commonwealth Seniors Health Card, or Pensioner Concession Card.
* NamingSystem: [AustralianHPII](NamingSystem-HPII.md)
  * ?: This namespace is used to represent Healthcare Provider Identifier for Individuals (HPI-I) numbers.
* NamingSystem: [AustralianHPIO](NamingSystem-HPIO.md)
  * ?: This namespace is used to represent Healthcare Provider Identifier for Organisations (HPI-O) numbers.
* NamingSystem: [AustralianIHI](NamingSystem-IHI.md)
  * ?: Australian Individual Healthcare Identifier (IHI). An IHI is assigned under the Healthcare Identifiers (HI) Service to a patient.
* NamingSystem: [AustralianPAI-D](NamingSystem-AUHPAI-D.md)
  * ?: This identifier profile defines a My Health Record Assigned Identity - Device (PAI-D) identifier in an Australian context. A PAI-D is typically used to identify a device that plays a role, for example an authoring or observing, in the exchange of digital health data with the My Health Record system.
* NamingSystem: [CAEI](NamingSystem-CAEI.md)
  * ?: A CAE identifier may be issued to an employee of, or person under contracted arrangement with, a care agency who wishes to participate in the My Health Record.
* NamingSystem: [CSPRN](NamingSystem-CSPRegistrationNumber.md)
  * ?: A CSP registration number may be issued to organisations who wish to participate in the My Health Record and/or the Healthcare Identifiers Service as a CSP.
* NamingSystem: [DPID](NamingSystem-AUDeliveryPointIdentifier.md)
  * ?: A DPID is a randomly generated, unique 8-digit number, allocated by Australia Post to an address. A DPID enables each delivery point in Australia to be uniquely identified.
* NamingSystem: [GNAFID](NamingSystem-AUGNAFIdentifier.md)
  * ?: Geoscape G-NAF is the geocoded address database for Australian businesses and governments.
* NamingSystem: [LSPN](NamingSystem-LSPN.md)
  * ?: Location Specific Practice Number. A Location Specific Practice Number (LSPN) is an identifier assigned to a specific location by Services Australia under the Medicare program and identifies an accredited practice site that provides diagnostic imaging and radiation oncology services.
* NamingSystem: [MedicareNumber](NamingSystem-MedicareNumber.md)
  * ?: Medicare Card Number. A Medicare card is provided to individuals who are enrolled in Medicare. This identifier system may be used for the 10 digit Medicare card number or the 11 digit number that includes the individual reference number (IRN).
* NamingSystem: [MedicareProviderNumber](NamingSystem-MedicareProviderNumber.md)
  * ?: Medicare Provider Number. A Medicare provider number is assigned by Services Australia under the Medicare program to practitioners who provide services that are eligible for a Medicare benefit. A practitioner may have more than one Medicare provider number if they deliver health services in different locations or are registered in multiple health professions.
* NamingSystem: [NPIO](NamingSystem-NPIO.md)
  * ?: A National Provider Identifier at Organisation (NPIO) uniquely identifies an individual practitioner at an organisation using the practitioner’s HPI-I and organisation’s HPI-O to form the NPIO.
* NamingSystem: [PAIO](NamingSystem-AUHPAI-O.md)
  * ?: This identifier profile defines a My Health Record Assigned Identity - Organisation (PAI-O) identifier in an Australian context. A PAI-O may be issued to organisations who wish to participate in the My Health Record and who are not eligible for a Healthcare Provider Identifier - Organisation (HPI-O).
* NamingSystem: [PAIR](NamingSystem-AUHPAI-R.md)
  * ?: This identifier profile defines a My Health Record Assigned Identity - Repository (PAI-R) identifier in an Australian context. A PAI-R is typically used to identify a conformant repository that plays a role in the exchange of digital health data with the My Health Record system.
* NamingSystem: [PBSPrescriberNumber](NamingSystem-PBSPrescriberNumber.md)
  * ?: Pharmaceutical Benefits Scheme (PBS) prescriber number. A PBS prescriber number is assigned by Services Australia under the Pharmaceutical Benefits Scheme to practitioners who are approved to prescribe PBS medicines under the National Health Act 1953.
* NamingSystem: [PHAN](NamingSystem-PharmacyApprovalNumber.md)
  * ?: Pharmacy Approval Number. A pharmacy approval number, also known as a PBS approval number, is assigned by the Department of Health to pharmacies that are approved to supply pharmaceutical benefits at particular premises under the National Health Act 1953.
* NamingSystem: [RACS](NamingSystem-RACS.md)
  * ?: Residential Aged Care Service identifier. A RACS ID (also referred to as a residential aged care facility service identifier (RACF ID)) is assigned by DOHAC to a subsidised residential aged care service.

