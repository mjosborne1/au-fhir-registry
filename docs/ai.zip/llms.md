# hl7.fhir.au-fhir-registry#0.1.0: HL7 AU FHIR Namespace registry

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### ImplementationGuides

* [HL7 AU FHIR Namespace registry](index.md)

### NamingSystems

* [ABN](NamingSystem-ABN.md)
* [ARBN](NamingSystem-ABRN.md)
* [ACN](NamingSystem-ACN.md)
* [AHPRANumber](NamingSystem-AHPRANumber.md)
* [DPID](NamingSystem-AUDeliveryPointIdentifier.md)
* [G-NAFID](NamingSystem-AUG-NAFIdentifier.md)
* [AustralianPAI-D](NamingSystem-AUHPAI-D.md)
* [PAIO](NamingSystem-AUHPAI-O.md)
* [PAIR](NamingSystem-AUHPAI-R.md)
* [AUNATAAccreditationNumber](NamingSystem-AUNATAAccreditationNumber.md)
* [AUNATASiteNumber](NamingSystem-AUNATASiteNumber.md)
* [CAEI](NamingSystem-CAEI.md)
* [CSPRN](NamingSystem-CSPRegistrationNumber.md)
* [AustralianCRN](NamingSystem-CentrelinkCustomerReferenceNumber.md)
* [AustalianDVAFileNumber](NamingSystem-DVANumber.md)
* [AustralianHPII](NamingSystem-HPI-I.md)
* [AustralianHPIO](NamingSystem-HPI-O.md)
* [AustralianIHI](NamingSystem-IHI.md)
* [LSPN](NamingSystem-LSPN.md)
* [MedicareNumber](NamingSystem-MedicareNumber.md)
* [MedicareProviderNumber](NamingSystem-MedicareProviderNumber.md)
* [NPIO](NamingSystem-NPIO.md)
* [PBSPrescriberNumber](NamingSystem-PBSPrescriberNumber.md)
* [PHAN](NamingSystem-PharmacyApprovalNumber.md)
* [RACS](NamingSystem-RACS.md)
