# hl7.fhir.au.nsregister#0.1.0: HL7 AU FHIR Namespace registry

## Pages

* [Home](index.md)
* [Artifacts](artifacts.md)

## Resources

### ImplementationGuides

* [HL7 AU FHIR Namespace registry](index.md)

### NamingSystems

* [ABN](NamingSystem-ABN.md)
* [ACN](NamingSystem-ACN.md)
* [AHPRANumber](NamingSystem-AHPRANumber.md)
* [ARBN](NamingSystem-ARBN.md)
* [DPID](NamingSystem-AUDeliveryPointIdentifier.md)
* [GNAFID](NamingSystem-AUGNAFIdentifier.md)
* [PAIO](NamingSystem-AUHPAI-O.md)
* [PAIR](NamingSystem-AUHPAI-R.md)
* [AustralianPAID](NamingSystem-AUHPAID.md)
* [AUNATAAccreditationNumber](NamingSystem-AUNATAAccreditationNumber.md)
* [AUNATASiteNumber](NamingSystem-AUNATASiteNumber.md)
* [CAEI](NamingSystem-CAEI.md)
* [CSPRN](NamingSystem-CSPRegistrationNumber.md)
* [AustralianCRN](NamingSystem-CentrelinkCustomerReferenceNumber.md)
* [AustalianDVAFileNumber](NamingSystem-DVANumber.md)
* [AustralianHPII](NamingSystem-HPII.md)
* [AustralianHPIO](NamingSystem-HPIO.md)
* [AustralianIHI](NamingSystem-IHI.md)
* [LSPN](NamingSystem-LSPN.md)
* [MedicareNumber](NamingSystem-MedicareNumber.md)
* [MedicareProviderNumber](NamingSystem-MedicareProviderNumber.md)
* [NPIO](NamingSystem-NPIO.md)
* [PBSPrescriberNumber](NamingSystem-PBSPrescriberNumber.md)
* [PHAN](NamingSystem-PharmacyApprovalNumber.md)
* [RACS](NamingSystem-RACS.md)
